# Daily UI #013 | Direct Messaging

A Pen created on CodePen.io. Original URL: [https://codepen.io/mubangadv/pen/rXrOQa](https://codepen.io/mubangadv/pen/rXrOQa).

I had a lot of fun with todays challange! 

At first I envisioned  a messaging app leaning heavy on the "frosted glass" look. But by the time I had my layout done and was ready to start styling, I noticed that the minimal look that the design had, and thought it was really cool. I always liked this high contrast minimal look with a lot of soft shadows, but I am usually to insecure about my  design skills to persue them fully. But today I was like what the heck why no go for it, and I really liked the way it turned out.

I might still fork this one in the future though and make the frosted glass styling because I still think it would look nice as well.

In terms of UX, I picture this as a DM system at a social site that is pinned to the bottom right of the screen (with probably a 4rem padding). You can easily switch between conversations with the panel on the left, that expands when you hover it.

I also enjoyed thinking about my favorite Marvel quotes as content for the chats.
